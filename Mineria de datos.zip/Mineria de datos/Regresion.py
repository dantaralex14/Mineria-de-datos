import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

data = pd.read_csv('Raisin_Dataset.csv')
data['Class'] = data['Class'].replace({'Kecimen': 0, 'Besni': 1})
X = data.drop('Class', axis=1) 
y = data['Class']
scaler = StandardScaler()
X = scaler.fit_transform(X)

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def log_likelihood(X, y, weights, regularization_strenght):
    scores = np.dot(X, weights)
    n = X.shape[0]
    epsilon = 1e-5
    y_pred = sigmoid(scores)
    log_likelihood = np.sum(y * np.log(y_pred + epsilon) + (1 - y) * np.log(1 - y_pred + epsilon))
    return log_likelihood

def gradient(X, y, weights):
    predicciones = sigmoid(np.dot(X, weights))
    error = y - predicciones
    gradient = np.dot(X.T, error)
    return gradient

def train_logistic_regression(X, y, learning_rate, num_iteraciones, regularization_strenght):
    weights = np.zeros(X.shape[1])
    for i in range(num_iteraciones):
        grad = gradient(X, y, weights)
        weights += learning_rate * grad
        if i % 1000 == 0:
            print(f'Iteración {i}: Log-likelihood = {log_likelihood(X, y, weights, regularization_strenght)}')   
    return weights

learning_rate = 0.01
num_iteraciones = 10000
regularization_strength = 0.1
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
weights = train_logistic_regression(X_train, y_train, learning_rate, num_iteraciones, regularization_strength)
print("Parámetros estimados para la regresión logística:", weights)

def predict(X, weights):
    scores = np.dot(X, weights)
    predicdion_probs = sigmoid(scores)
    predichas_etiquetas = (predicdion_probs > 0.5).astype(int)
    return predichas_etiquetas

y_pred = predict(X_test, weights)
precision = np.mean(y_pred == y_test)
print(f'Precisión del modelo: {precision}')

radio_error = np.mean(y_pred != y_test)
print(f'Porcentaje de error entre las clases de los datos de prueba y las calculadas por Regresión Logística: {radio_error}')

for i in range(len(X_test)):
    print(f'Clase predicha para el dato de prueba {i}: {y_pred[i]}')
