import re
import colorama
import requests
from bs4 import BeautifulSoup

Resultado = requests.get('https://www.ucol.mx/estudia-udec/oferta-superior-licenciatura.htm')


soup = BeautifulSoup(Resultado.text, "html.parser")
Encuentra = soup.find_all('h5')

print(soup)
print(Encuentra)

print(Resultado.text)

patron = r"Licenciatura en[\D-]*"
patron2 = r"Ingeniería en[\D-]*"
Encontradas = re.findall(patron, Resultado.text)
Encontradas2 = re.findall(patron2, Resultado.text)

for Resulta in Encontradas:
    print(Resulta)

for Resulta2 in Encontradas2:
    print(Resulta2)
