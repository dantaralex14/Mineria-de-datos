import pandas as pd
import numpy as np
import math
from sklearn.model_selection import train_test_split

data = pd.read_csv("Raisin_Dataset.csv")
X = data.drop('Class', axis=1)
y = data['Class']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

def probabilidades(data):
    kecimen = (data['Class'] == "Kecimen").sum()
    besni = (data['Class'] == "Besni").sum()

    probabilidad_kecimen = kecimen / len(data['Class'])
    probabilidad_besni = besni / len(data['Class'])

    return probabilidad_kecimen, probabilidad_besni

def probabilidad_gaussiana(x, mean, std):
    exponent = math.exp(-((x - mean) ** 2) / (2 * std ** 2))
    return (1 / (math.sqrt(2 * math.pi) * std)) * exponent

def clase_predicha(X_test, prob_k, prob_b, mean_k, std_k, mean_b, std_b):
    predicciones = []
    for index, row in X_test.iterrows():
        prob_k_given_x = prob_k * np.prod([probabilidad_gaussiana(row[feature], mean_k[feature], std_k[feature]) for feature in X_test.columns])
        prob_b_given_x = prob_b * np.prod([probabilidad_gaussiana(row[feature], mean_b[feature], std_b[feature]) for feature in X_test.columns])
        
        if prob_k_given_x > prob_b_given_x:
            predicciones.append("Kecimen")
        else:
            predicciones.append("Besni")
    return predicciones

prob_k, prob_b = probabilidades(data)
mean_k = X_train[y_train == "Kecimen"].mean()
std_k = X_train[y_train == "Kecimen"].std()
mean_b = X_train[y_train == "Besni"].mean()
std_b = X_train[y_train == "Besni"].std()

predictions = clase_predicha(X_test, prob_k, prob_b, mean_k, std_k, mean_b, std_b)
precision = (predictions == y_test).mean()

for i, (clase_real, clase_predecida) in enumerate(zip(y_test.values, predictions), 1):
    print(f"Nuevo dato {i}:")
    print(f"Clase real: {clase_real}")
    print(f"Clase predicha: {clase_predecida}")
    print()

porcentaje_error = 100 * (1 - precision)
print("Porcentaje de error entre las clases de los datos de prueba y las calculadas por Bayes:", porcentaje_error)
