import numpy as np
import pandas as pd
from scipy.optimize import minimize
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_classification

# Generar datos de ejemplo con tres variables predictoras
np.random.seed(0)
X, y = make_classification(n_samples=1000, n_features=3, n_informative=3, n_redundant=0, n_classes=2)

# Función de regresión logística
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def log_likelihood(params, X, y):
    n = X.shape[0]
    ProductoPunto = np.dot(X, params)
    y_pred = sigmoid(np.dot(X, params))
    likelihood = np.sum(y * np.log(y_pred) + (1 - y) * np.log(1 - y_pred))
    i=1
    return likelihood

def neg_log_likelihood(params, X, y):
    T=-log_likelihood(params, X, y)
    return -log_likelihood(params, X, y)

# Estimación inicial de los parámetros
initial_guess = np.zeros(X.shape[1])

# Optimización de los parámetros usando el método de máxima verosimilitud
resultado = minimize(neg_log_likelihood, initial_guess, args=(X, y), method='BFGS')
parametros_estimados = resultado.x

# Resultados
print("Parámetros estimados para la regresión logística:", parametros_estimados)