import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import re

nltk.download('punkt')
nltk.download('stopwords')

def remove_punctuation(text):
    return re.sub(r'[^\w\s]', '', text)

def tokenize_and_normalize(text):
    tokens = word_tokenize(text.lower())
    normalized_tokens = []
    for token in tokens:
        token = remove_punctuation(token)
        if token and token not in stop_words and not token.isdigit():
            normalized_tokens.append(token)
    return normalized_tokens

def generate_word_pairs(words, window_size):
    word_to_index = {word: index for index, word in enumerate(words)}
    index_to_word = {index: word for index, word in enumerate(words)}
    
    pairs = []
    for i, word in enumerate(words):
        start = max(0, i - window_size)
        end = min(len(words), i + window_size + 1)
        
        for j in range(start, end):
            if i != j:
                pairs.append((word_to_index[word], word_to_index[words[j]]))
    
    return pairs, word_to_index, index_to_word

def write_output_to_file(filename, corpus_size, pairs, index_to_word):
    with open(filename, 'w') as file:
        file.write(f"Tamaño de corpus: {corpus_size}\n")
        file.write("Pares de índices y palabras:\n")
        for pair in pairs:
            word1 = index_to_word[pair[0]]
            word2 = index_to_word[pair[1]]
            file.write(f"{pair[0]} {pair[1]} ({word1}, {word2})\n")

# Cargar las palabras de parada en español
stop_words = set(stopwords.words('spanish'))

# Leer el texto del archivo
with open('sistemas formales.txt', 'r') as file:
    text = file.read()

# Tokenizar y normalizar el texto
tokens = tokenize_and_normalize(text)

# Generar el conjunto de palabras
word_set = set(tokens)

# Definir el tamaño de la ventana
window_size = 2

# Generar los pares de palabras y los diccionarios de índices
pairs, word_to_index, index_to_word = generate_word_pairs(tokens, window_size)

# Mostrar los resultados
print("Pares de palabras generados:")
print(pairs)

print("\nEstructura de palabra a índice:")
print(word_to_index)

print("\nEstructura de índice a palabra:")
print(index_to_word)

# Escribir la salida en un archivo de texto
output_file_name = 'output.txt'
corpus_size = len(tokens)
write_output_to_file(output_file_name, corpus_size, pairs, index_to_word)

print(f"Resultados escritos en {output_file_name}")
