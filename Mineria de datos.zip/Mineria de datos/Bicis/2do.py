import pandas as pd

order_items = pd.read_csv('order_items.csv')
products = pd.read_csv('products.csv')

order_items = order_items.merge(products[['product_id', 'brand_id']], on='product_id')

top_marcas = order_items['brand_id'].value_counts().head(3)
print(top_marcas)
