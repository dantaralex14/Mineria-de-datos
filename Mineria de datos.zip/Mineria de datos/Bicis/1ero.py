import pandas as pd

stocks = pd.read_csv('stocks.csv')

products = pd.read_csv('products.csv')
stocks = stocks.merge(products, on='product_id')

stock_minimo = stocks.groupby(['store_id', 'brand_id'])['quantity'].min()
print(stock_minimo)
