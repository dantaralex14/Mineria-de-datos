import pandas as pd

order_items = pd.read_csv('order_items.csv')
products = pd.read_csv('products.csv')
stores = pd.read_csv('stores.csv')

merged_data = pd.merge(order_items, products, on='product_id')
merged_data = pd.merge(merged_data, stores, on='store_id')

merged_data['total_price'] = merged_data['quantity'] * merged_data['list_price']

ventas_dinero = merged_data.groupby(['store_id', 'store_name'])['total_price'].sum().reset_index()
ventas_cantidad = merged_data.groupby(['store_id', 'store_name'])['quantity'].sum().reset_index()

tienda_dinero = ventas_dinero.loc[ventas_dinero['total_price'].idxmax(), 'store_name']
tienda_cantidad = ventas_cantidad.loc[ventas_cantidad['quantity'].idxmax(), 'store_name']

print("Tienda con más ventas en dinero:", tienda_dinero)
print("Tienda con más ventas en cantidad de bicicletas:", tienda_cantidad)