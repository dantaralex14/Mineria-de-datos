import pandas as pd

order_items = pd.read_csv('order_items.csv')

top_bicicletas = order_items.sort_values(by='quantity', ascending=False)

print(top_bicicletas.head())